<!-- Experience Start -->
<div class="container-fluid pt-6 px-5">
    <div class="text-center mx-auto mb-5" style="max-width: 600px;">
        <h1 class="display-5 mb-0">Our Experience</h1>
        <hr class="w-25 mx-auto bg-primary">
    </div>

    <?php if (!empty($experiences)): ?>

        <?php if (count($experiences) == 1): ?>
            <!-- ONE Experience → Full -->
            <div class="row justify-content-center">
                <div class="col-lg-10">
                   <div class="bg-secondary p-5 rounded fs-4 lh-lg">
    <?= $experiences[0]['description']; ?>
</div>

                </div>
            </div>

        <?php else: ?>
            <!-- MULTIPLE Experiences -->
            <div class="row g-5">
                <?php foreach ($experiences as $exp): ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="bg-secondary p-4 rounded h-100">
                            <?= $exp['description']; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

    <?php else: ?>
        <div class="text-center">
            <p>No experience data available.</p>
        </div>
    <?php endif; ?>
</div>
<!-- Experience End -->
