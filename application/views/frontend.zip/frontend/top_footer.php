<!-- Footer / Contact Section Start -->
<div class="container-fluid bg-secondary px-lg-5 px-md-4 px-3">
    <div class="row g-0">
        <!-- Contact Form -->
        <div class="col-lg-6 py-6 d-flex flex-column">
            <h1 class="display-5 mb-4">You can connect with us when need help!</h1>
            <h4 class="lh-base mb-4">
                Please send any specific information about your request so we can direct it to the appropriate people:
            </h4>
            <form class="flex-grow-1">
                <div class="row g-3">
                    <div class="col-12 col-md-6">
                        <div class="form-floating">
                            <input type="text" class="form-control" id="form-floating-1" placeholder="John Doe">
                            <label for="form-floating-1">Full Name</label>
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <div class="form-floating">
                            <input type="email" class="form-control" id="form-floating-2" placeholder="name@example.com">
                            <label for="form-floating-2">Email address</label>
                        </div>
                    </div>

                    <!-- Phone Number -->
                    <div class="col-12 col-md-6">
                        <div class="form-floating">
                            <input type="tel" class="form-control" id="form-floating-5" placeholder="+251 900 000 000">
                            <label for="form-floating-5">Phone Number</label>
                        </div>
                    </div>

                    <div class="col-12 col-md-6">
                        <div class="form-floating">
                            <input type="text" class="form-control" id="form-floating-3" placeholder="Subject">
                            <label for="form-floating-3">Subject</label>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="form-floating">
                            <textarea class="form-control" placeholder="Message" id="form-floating-4" style="height: 150px"></textarea>
                            <label for="form-floating-4">Message</label>
                        </div>
                    </div>

                    <div class="col-12">
                        <button class="btn bg-primary text-white w-100 py-3" type="submit">Submit</button>
                    </div>
                </div>
            </form>
        </div>
        <!-- Google Map -->
        <div class="col-lg-6 d-flex align-items-stretch mt-4 mt-lg-0">
            <iframe class="w-100 h-100"
                src="<?= isset($settings[0]['address']) ? $settings[0]['address'] : ''; ?>"
                frameborder="0" style="border:0; min-height: 100%;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
        </div>
    </div>
</div>

<style>
/* Make the map iframe responsive and match contact form height */
.col-lg-6 iframe {
    width: 100%;
    height: 100%;
    min-height: 500px;
    border: 0;
}

@media (max-width: 992px) {
    .col-lg-6 {
        min-height: auto; /* Let sections stack naturally */
    }
    .col-lg-6 iframe {
        height: 400px; /* Mobile friendly height */
    }
    /* Optional: reduce padding on mobile */
    .px-lg-5 { padding-left: 1rem !important; padding-right: 1rem !important; }
}
</style>
